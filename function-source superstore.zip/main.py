from google.cloud import bigquery, storage
import pandas as pd

def process_dataset(request):
    """Triggered by a change in a Cloud Storage bucket."""
    # Initialize GCP clients
    storage_client = storage.Client()
    bigquery_client = bigquery.Client()

    # Configuration
    bucket_name = "samplesagarsoft"  # Replace with your bucket name
    file_name = "team1/Cleaned_Superstore_Sales.csv"  # File path in the bucket
    project_id = "deductive-anvil-442218-h5"  # Replace with your GCP project ID
    bronze_dataset = "dataset_bronze"
    bronze_table = "superstore_sales_raw"
    silver_dataset = "dataset_silver"
    silver_table = "superstore_sales_clean"
    gold_dataset = "dataset_gold"
    gold_table = "superstore_sales_summary"

    # Step 1: Define GCS file URI
    uri = f"gs://{bucket_name}/{file_name}"
    print(f"Processing file: {uri}")

    # Step 2: Load raw data to the Bronze layer
    bronze_table_id = f"{project_id}.{bronze_dataset}.{bronze_table}"
    job_config = bigquery.LoadJobConfig(
        source_format=bigquery.SourceFormat.CSV,
        skip_leading_rows=1,
        autodetect=True,
    )
    load_job = bigquery_client.load_table_from_uri(uri, bronze_table_id, job_config=job_config)
    load_job.result()
    print(f"Data loaded to Bronze table: {bronze_table_id}")

    # Step 3: Query data from the Bronze layer
    bronze_query = f"SELECT * FROM `{bronze_table_id}`"
    df_bronze = bigquery_client.query(bronze_query).to_dataframe()
    print("Loaded DataFrame from Bronze layer:")
    print(df_bronze.head())

    # Step 4: Transform data for the Silver layer
    # Remove duplicates and null values
    df_silver = df_bronze.dropna().drop_duplicates()
    print("Transformed DataFrame for Silver layer:")
    print(df_silver.head())

    # Step 5: Upload transformed data to the Silver layer
    silver_table_id = f"{project_id}.{silver_dataset}.{silver_table}"
    df_silver.to_gbq(silver_table_id, project_id=project_id, if_exists="replace")
    print(f"Transformed data uploaded to Silver table: {silver_table_id}")

    # Step 6: Process data for the Gold layer
    # Aggregation Example: Total sales by Category
    gold_query = f"""
    SELECT 
        Category, 
        SUM(Sales) AS total_sales
    FROM `{silver_table_id}`
    GROUP BY Category
    """
    gold_df = bigquery_client.query(gold_query).to_dataframe()
    print("Aggregated DataFrame for Gold layer:")
    print(gold_df.head())

    # Step 7: Upload aggregated data to the Gold layer
    gold_table_id = f"{project_id}.{gold_dataset}.{gold_table}"
    gold_df.to_gbq(gold_table_id, project_id=project_id, if_exists="replace")
    print(f"Processed data uploaded to Gold table: {gold_table_id}")

    print("Data processing pipeline completed.")
    return "Pipeline executed successfully", 200
